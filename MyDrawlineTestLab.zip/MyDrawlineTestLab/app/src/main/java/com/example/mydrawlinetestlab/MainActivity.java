package com.example.mydrawlinetestlab;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private DrawLine drawLine;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawLine = (DrawLine) findViewById(R.id.drawLine);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void showAlertDialog(){
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ConstraintLayout layout = (ConstraintLayout) inflater.inflate(R.layout.custom_dialogbox,null);
        TextView textView = (TextView) layout.findViewById(R.id.textView);
        SeekBar seekBar = (SeekBar) layout.findViewById(R.id.seekBar);
        new AlertDialog.Builder(this).setTitle("Line Thickness").setView(layout).setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this,"You clicked cancel button.",Toast.LENGTH_SHORT).show();
            }
        }).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                float value = seekBar.getProgress();
                drawLine.setLineStroke((int)value);
                Toast.makeText(MainActivity.this,"You clicked ok button.",Toast.LENGTH_SHORT).show();
            }
        }).show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getTitle() == getResources().getString(R.string.softYellow)){
            drawLine.setBackgroundColor(getColor(R.color.softYellow));
        }
        if(item.getTitle() == getResources().getString(R.string.softBlue)){
            drawLine.setBackgroundColor(getColor(R.color.softblue));
        }
        if(item.getTitle() == getResources().getString(R.string.softGreen)){
            drawLine.setBackgroundColor(getColor(R.color.softgreen));
        }
        if(item.getTitle() == getResources().getString(R.string.red)){
            drawLine.changeColor(getResources().getString(R.string.red));
        }
        if(item.getTitle() == getResources().getString(R.string.deepBlue)){
            drawLine.changeColor(getResources().getString(R.string.deepBlue));
        }
        if(item.getTitle() == getResources().getString(R.string.lineThickness)){
            showAlertDialog();
        }
        if(item.getTitle() == getResources().getString(R.string.clear)){
            drawLine.clearCanvas();
        }

        return super.onOptionsItemSelected(item);
    }
}