package com.example.studentdatabasewithroom;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class StudentRepository {
    private StudentDao studentDao;
    private LiveData<List<Student>> listStudent;
    StudentRepository(Application application){
        StudentRoomDatabase studentDb = StudentRoomDatabase.getDatabase(application);
        studentDao = studentDb.studentDao();
        listStudent = studentDao.getAllStudents();
    }
    LiveData<List<Student>> getAllStudent(){
        return listStudent;
    }
    void insert(Student student){
        StudentRoomDatabase.databaseWriteExecutor.execute(()->{
            studentDao.insert(student);
        });
    }
}
