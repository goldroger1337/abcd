package com.example.studentdatabasewithroom;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class StudentViewModel extends AndroidViewModel {
    private StudentRepository studentRepository;
    private final LiveData<List<Student>> listStudent;

    public StudentViewModel(@NonNull Application application) {
        super(application);
        studentRepository = new StudentRepository(application);
        listStudent = studentRepository.getAllStudent();
    }
    LiveData<List<Student>> getAllStudent(){
        return listStudent;
    }
    void insert(Student student){
        studentRepository.insert(student);
    }
}
