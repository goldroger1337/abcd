package com.example.customviewassignment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


public class MainActivity extends AppCompatActivity {
    private DrawLine drawLine;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawLine=(DrawLine) findViewById(R.id.drawLine);
        toolbar=(Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getTitle()==getResources().getString(R.string.softyellow))
        {
            drawLine.setBackgroundColor(getColor(R.color.softyellow));
        }
        if(item.getTitle()==getResources().getString(R.string.softBlue))
        {
            drawLine.setBackgroundColor(getColor(R.color.softblue));
        }
        if(item.getTitle()==getResources().getString(R.string.softGreen))
        {
            drawLine.setBackgroundColor(getColor(R.color.softgreen));
        }
        if(item.getTitle()==getResources().getString(R.string.red))
        {
            drawLine.ChangeColor(getResources().getString(R.string.red));
        }
        if(item.getTitle()==getResources().getString(R.string.deepblue))
        {
            drawLine.ChangeColor(getResources().getString(R.string.deepblue));
        }
        return super.onOptionsItemSelected(item);
    }
}