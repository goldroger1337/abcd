package com.example.studentdatabasewithroom;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "student_table")
public class Student {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "mkpt")
    private String mkpt;
    @NonNull
    @ColumnInfo(name = "name")
    private String name;
    @NonNull
    @ColumnInfo(name = "year")
    private String year;
    @ColumnInfo(name = "gpa")
    private String gpa;

    public Student(@NonNull String mkpt, @NonNull String name, @NonNull String year, String gpa) {
        this.mkpt = mkpt;
        this.name = name;
        this.year = year;
        this.gpa = gpa;
    }

    @NonNull
    public String getMkpt() {
        return mkpt;
    }

    public void setMkpt(@NonNull String mkpt) {
        this.mkpt = mkpt;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    @NonNull
    public String getYear() {
        return year;
    }

    public void setYear(@NonNull String year) {
        this.year = year;
    }

    public String getGpa() {
        return gpa;
    }

    public void setGpa(String gpa) {
        this.gpa = gpa;
    }
}
