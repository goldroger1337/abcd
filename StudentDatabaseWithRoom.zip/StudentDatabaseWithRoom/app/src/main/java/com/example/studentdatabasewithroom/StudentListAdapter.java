package com.example.studentdatabasewithroom;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StudentListAdapter extends RecyclerView.Adapter<StudentListAdapter.StudentViewHolder> {
    ArrayList<Student> listStudent;

    public StudentListAdapter(ArrayList<Student> listStudent) {
        this.listStudent = listStudent;
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = (View) inflater.inflate(R.layout.student_item,parent,false);
        return new StudentViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        //Student s = listStudent.get(position);
        holder.textViewMkpt.setText(listStudent.get(position).getMkpt());
        holder.textViewName.setText(listStudent.get(position).getName());
        holder.textViewYear.setText(listStudent.get(position).getYear());
        holder.textViewGpa.setText(listStudent.get(position).getGpa());

    }

    @Override
    public int getItemCount() {
        return listStudent.size();
    }

    class StudentViewHolder extends RecyclerView.ViewHolder{
        TextView textViewMkpt;
        TextView textViewName;
        TextView textViewYear;
        TextView textViewGpa;

        public StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewMkpt = (TextView) itemView.findViewById(R.id.textViewMKPT);
            textViewName = (TextView) itemView.findViewById(R.id.textViewName);
            textViewYear = (TextView) itemView.findViewById(R.id.textViewYear);
            textViewGpa = (TextView) itemView.findViewById(R.id.textViewGPA);
        }
    }
}
