package com.example.studentdatabasewithroom;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText editTextMkpt,editTextName,editTextYear,editTextGpa;
    Button button;
    RecyclerView recyclerView;
    StudentViewModel studentViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextMkpt = (EditText) findViewById(R.id.editTextMKPT);
        editTextName = (EditText) findViewById(R.id.editTextName);
        editTextYear = (EditText) findViewById(R.id.editTextYear);
        editTextGpa = (EditText) findViewById(R.id.editTextGPA);
        button = (Button) findViewById(R.id.buttonSave);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        studentViewModel = new ViewModelProvider(this).get(StudentViewModel.class);

        studentViewModel.getAllStudent().observe(this,students->{
            if(students!=null && !students.isEmpty()){
                final StudentListAdapter adapter = new StudentListAdapter((ArrayList<Student>) students);
                recyclerView.setAdapter(adapter);
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Student student = new Student(editTextMkpt.getText().toString(),editTextName.getText().toString(),editTextYear.getText().toString(),editTextGpa.getText().toString());
                studentViewModel.insert(student);
            }
        });
    }
}